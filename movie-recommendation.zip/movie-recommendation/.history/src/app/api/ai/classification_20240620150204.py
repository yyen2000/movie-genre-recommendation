import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import pickle

# Load dataset
df = pd.read_csv('movie_set.csv')  # Ensure the CSV contains 'title', 'overview', and 'genre'

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])  # Remove rows with missing 'overview'

# Text preprocessing and model training
X = df['overview']
y = df['genres']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline that vectorizes the text and then applies Naive Bayes
model = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('nb', MultinomialNB()),
])

# Train the model
model.fit(X_train, y_train)

# Save the model to a file
with open('movie_genre_classifier.pkl', 'wb') as f:
    pickle.dump(model, f)
