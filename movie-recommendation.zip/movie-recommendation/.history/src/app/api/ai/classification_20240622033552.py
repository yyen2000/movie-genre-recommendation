import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score, precision_score
from sklearn.model_selection import GridSearchCV
from sklearn.utils.class_weight import compute_sample_weight
import pickle

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Adjust path as necessary

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])

# Convert genres from string representation of list of dicts to list of genres
df['genres'] = df['genres'].apply(lambda x: [genre['name'] for genre in eval(x)])

# Text preprocessing
X = df['overview']
y = df['genres']

# Use MultiLabelBinarizer to convert genres to a binary matrix
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(y)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Calculate sample weights to handle class imbalance
sample_weights = compute_sample_weight(class_weight='balanced', y=y_train)

# Define parameter grid for hyperparameter tuning
param_grid = {
    'clf__estimator__n_estimators': [100, 200],
    'clf__estimator__max_depth': [None, 10, 20],
    'clf__estimator__min_samples_split': [2, 5, 10],
}

# Create a pipeline with RandomForestClassifier
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),
    ('clf', MultiOutputClassifier(RandomForestClassifier(random_state=42)))
])

# Perform GridSearchCV to find the best parameters
grid_search = GridSearchCV(pipeline, param_grid, cv=3, scoring='f1_weighted', verbose=1, n_jobs=-1)
grid_search.fit(X_train, y_train, clf__estimator__sample_weight=sample_weights)

# Best parameters found by GridSearchCV
best_params = grid_search.best_params_
print(f'Best parameters: {best_params}')

# Train the model using the best parameters
best_model = grid_search.best_estimator_
best_model.fit(X_train, y_train)

# Predict on test data
y_pred = best_model.predict(X_test)

# Print classification report
report = classification_report(y_test, y_pred, target_names=mlb.classes_)
print(report)

# Calculate and print accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy:.4f}')

# Calculate and print precision
precision = precision_score(y_test, y_pred, average='weighted')
print(f'Weighted Precision: {precision:.4f}')

# Save the best model and MultiLabelBinarizer
with open('movie_genre_classifier_rf_tuned.pkl', 'wb') as f:
    pickle.dump((best_model, mlb), f)
