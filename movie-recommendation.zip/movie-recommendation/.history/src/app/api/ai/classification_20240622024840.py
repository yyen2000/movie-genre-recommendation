import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import classification_report, accuracy_score, precision_score
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
import pickle

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Adjust path as necessary

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])

# Convert genres from string representation of list of dicts to list of genres
df['genres'] = df['genres'].apply(lambda x: [genre['name'] for genre in eval(x)])

# Text preprocessing
X = df['overview']
y = df['genres']

# Use MultiLabelBinarizer to convert genres to a binary matrix
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(y)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create TF-IDF vectorizer
tfidf_vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2))

# Fit and transform on training data
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)

# Transform test data
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Create a pipeline with RandomForestClassifier and GridSearchCV
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),
    ('clf', MultiOutputClassifier(RandomForestClassifier(random_state=42)))
])

# Define parameters for GridSearchCV
parameters = {
    'clf__estimator__n_estimators': [50, 100, 200],
    'clf__estimator__max_depth': [None, 10, 20],
    'clf__estimator__min_samples_leaf': [1, 2, 4],
}

# Initialize GridSearchCV
grid_search = GridSearchCV(pipeline, param_grid=parameters, cv=3, verbose=2)

# Train the model using GridSearchCV
grid_search.fit(X_train, y_train)

# Predict on test data
y_pred = grid_search.predict(X_test)

# Print classification report
report = classification_report(y_test, y_pred, target_names=mlb.classes_)
print(report)

# Print accuracy and precision scores
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='micro')  # Calculate precision for multi-label classification

print(f'Accuracy: {accuracy:.2f}')
print(f'Precision: {precision:.2f}')

# Save the best model and MultiLabelBinarizer
best_model = grid_search.best_estimator_
with open('movie_genre_classifier_rf_tuned.pkl', 'wb') as f:
    pickle.dump((best_model, mlb), f)
