from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import pandas as pd
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import pickle

nltk.download('stopwords')
nltk.download('wordnet')

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Ensure the CSV contains 'title', 'overview', and 'genre'

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])  # Remove rows with missing 'overview'

# Preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    tokens = text.split()
    tokens = [word for word in tokens if word not in stopwords.words('english')]
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(word) for word in tokens]
    return ' '.join(tokens)

# Apply preprocessing
df['clean_overview'] = df['overview'].apply(preprocess_text)

# Text preprocessing and model training
X = df['clean_overview']
y = df['genres']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline that vectorizes the text and then applies Naive Bayes
model = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('nb', MultinomialNB()),
])

# Train the model
model.fit(X_train, y_train)

# Evaluate the model
accuracy = model.score(X_test, y_test)
print(f'Accuracy: {accuracy:.4f}')

# Save the model to a file
with open('movie_genre_classifier.pkl', 'wb') as f:
    pickle.dump(model, f)
