import pickle

# Save the Naive Bayes model pipeline
with open('pipeline_nb.pkl', 'wb') as f:
    pickle.dump(pipeline_nb, f)

# Save the Random Forest model pipeline
with open('pipeline_rf.pkl', 'wb') as f:
    pickle.dump(pipeline_rf, f)
