from flask import Flask, request, jsonify
import pickle
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.multioutput import MultiOutputClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier

app = Flask(__name__)

# Load the trained models
with open('pipeline_nb.pkl', 'rb') as f:
    pipeline_nb = pickle.load(f)

with open('pipeline_rf.pkl', 'rb') as f:
    pipeline_rf = pickle.load(f)

# Define an endpoint for predicting genres
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    overview = data['overview']
    
    prediction_nb = pipeline_nb.predict([overview])
    prediction_rf = pipeline_rf.predict([overview])

    response = {
        'naive_bayes': prediction_nb.tolist(),
        'random_forest': prediction_rf.tolist()
    }

    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
