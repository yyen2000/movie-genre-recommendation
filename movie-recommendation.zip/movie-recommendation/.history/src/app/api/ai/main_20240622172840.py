from flask import Flask, request, jsonify
import pandas as pd
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline

app = Flask(__name__)

# Load and prepare the data
data = pd.read_csv('src/app/api/ai/cleaned_movie_set.csv')

def clean_genres(genres_str):
    genres_list = ast.literal_eval(genres_str)
    return [genre['name'] for genre in genres_list]

data['genres'] = data['genres'].apply(clean_genres)
data = data.dropna(subset=['overview'])

vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(data['genres'])

pipeline_nb = Pipeline([
    ('tfidf', vectorizer),
    ('clf', MultiOutputClassifier(MultinomialNB()))
])

pipeline_nb.fit(data['overview'], y)

@app.route('/predict', methods=['POST'])
def predict():
    content = request.json
    overview = content['overview']
    prediction = pipeline_nb.predict([overview])
    genres = mlb.inverse_transform(prediction)
    return jsonify({'predicted_genres': list(genres[0])})

if __name__ == '__main__':
    app.run(debug=True)
