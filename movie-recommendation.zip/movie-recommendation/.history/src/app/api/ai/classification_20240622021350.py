import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import pickle

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Ensure the CSV contains 'title', 'overview', and 'genre'

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])  # Remove rows with missing 'overview'

# Text preprocessing
X = df['overview']
y = df['genres']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline with TfidfVectorizer and MultinomialNB
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),  # Use bigrams
    ('nb', MultinomialNB()),
])

# Define parameter grid for GridSearchCV
param_grid = {
    'tfidf__max_df': [0.75, 1.0],
    'tfidf__min_df': [1, 5],
    'nb__alpha': [0.1, 0.5, 1.0],
}

# Perform grid search with cross-validation
grid_search = GridSearchCV(pipeline, param_grid, cv=5, n_jobs=-1, verbose=1)
grid_search.fit(X_train, y_train)

# Print best parameters and best score
print(f"Best parameters: {grid_search.best_params_}")
print(f"Best cross-validation score: {grid_search.best_score_:.4f}")

# Evaluate the best model on the test set
best_model = grid_search.best_estimator_
test_accuracy = best_model.score(X_test, y_test)
print(f"Test set accuracy: {test_accuracy:.4f}")

# Save the best model to a file
with open('movie_genre_classifier.pkl', 'wb') as f:
    pickle.dump(best_model, f)
