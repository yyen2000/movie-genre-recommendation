import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import classification_report
from sklearn.pipeline import Pipeline
import pickle

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Adjust path as necessary

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])

# Convert genres from string representation of list of dicts to list of genres
df['genres'] = df['genres'].apply(lambda x: [genre['name'] for genre in eval(x)])

# Text preprocessing
X = df['overview']
y = df['genres']

# Use MultiLabelBinarizer to convert genres to a binary matrix
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(y)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create TF-IDF vectorizer
tfidf_vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2))

# Fit and transform on training data
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)

# Transform test data
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Create a pipeline with RandomForestClassifier
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),
    ('clf', MultiOutputClassifier(RandomForestClassifier(random_state=42)))
])

# Train the model
pipeline.fit(X_train, y_train)

# Predict on test data
y_pred = pipeline.predict(X_test)

# Print classification report
report = classification_report(y_test, y_pred, target_names=mlb.classes_)
print(report)

# Save the model and MultiLabelBinarizer
with open('movie_genre_classifier_rf.pkl', 'wb') as f:
    pickle.dump((pipeline, mlb), f)
