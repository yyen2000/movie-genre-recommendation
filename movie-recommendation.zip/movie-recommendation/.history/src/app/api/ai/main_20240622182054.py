from flask import Flask, request, jsonify
import pickle
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load the trained models and the MultiLabelBinarizer
model_path_nb = os.path.join(os.path.dirname(__file__), 'pipeline_nb.pkl')
with open(model_path_nb, 'rb') as f:
    pipeline_nb = pickle.load(f)

model_path_rf = os.path.join(os.path.dirname(__file__), 'pipeline_rf.pkl')
with open(model_path_rf, 'rb') as f:
    pipeline_rf = pickle.load(f)

mlb_path = os.path.join(os.path.dirname(__file__), 'mlb.pkl')
with open(mlb_path, 'rb') as f:
    mlb = pickle.load(f)

# Define an endpoint for predicting genres
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    overview = data['overview']
    
    prediction_nb = pipeline_nb.predict([overview])
    prediction_rf = pipeline_rf.predict([overview])

    # Convert binary predictions to genre names
    genres_nb = mlb.inverse_transform(prediction_nb)
    genres_rf = mlb.inverse_transform(prediction_rf)

    response = {
        'naive_bayes': genres_nb[0],  # Access the first element from the list
        'random_forest': genres_rf[0]  # Access the first element from the list
    }

    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
