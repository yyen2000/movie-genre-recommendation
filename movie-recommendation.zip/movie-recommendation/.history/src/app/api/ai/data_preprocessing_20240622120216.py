import ast
import pandas as pd

# Load the dataset
file_path = 'src/app/api/ai/cleaned_movie_set.csv'
data = pd.read_csv(file_path)

# Display the first few rows of the dataset to understand its structure
data.head(), data.info()

# Function to clean and convert the 'genres' column
def clean_genres(genre_str):
    try:
        genre_list = ast.literal_eval(genre_str)
        return [genre['name'] for genre in genre_list]
    except (ValueError, SyntaxError):
        return []

# Clean the 'genres' column
data['genres'] = data['genres'].apply(clean_genres)

# Drop rows with missing 'overview'
data.dropna(subset=['overview'], inplace=True)

# Remove special characters from 'original_title' and 'overview'
data['original_title'] = data['original_title'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)
data['overview'] = data['overview'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)

# Display the cleaned data
data.head(), data.info()
