import pandas as pd
import ast

# Load the dataset
file_path = 'src/app/api/ai/movie_set.csv'  # Update this path to your actual file path
data = pd.read_csv(file_path)

# Function to validate and clean the JSON-like genre strings
def validate_genres(genre_str):
    try:
        # Parse the JSON-like string
        genre_list = ast.literal_eval(genre_str)
        # Ensure it is a list of dictionaries with 'id' and 'name' keys
        if isinstance(genre_list, list) and all(isinstance(genre, dict) and 'id' in genre and 'name' in genre for genre in genre_list):
            return genre_list
        else:
            return []
    except (ValueError, SyntaxError):
        return []

# Validate and clean the 'genres' column
data['genres'] = data['genres'].apply(validate_genres)

# Drop rows with missing 'overview'
data.dropna(subset=['overview'], inplace=True)

# Remove special characters from 'original_title' and 'overview'
data['original_title'] = data['original_title'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)
data['overview'] = data['overview'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)

# Save the cleaned dataset to a new CSV file
cleaned_file_path = 'src/app/api/ai/cleaned_movie_set_v2.csv'  # Update this path to your actual file path
data.to_csv(cleaned_file_path, index=False)
