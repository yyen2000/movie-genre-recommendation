# Import necessary libraries
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline

# Load the cleaned data
data = pd.read_csv('cleaned_movie_set.csv')

# Prepare the Data
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(data['genres'])

# Split the Data
X_train, X_test, y_train, y_test = train_test_split(data['overview'], y, test_size=0.2, random_state=42)

# Build Pipelines
pipeline_nb = Pipeline([
    ('tfidf', vectorizer),
    ('clf', MultiOutputClassifier(MultinomialNB()))
])

pipeline_rf = Pipeline([
    ('tfidf', vectorizer),
    ('clf', MultiOutputClassifier(RandomForestClassifier(n_estimators=100, random_state=42)))
])

# Train and Evaluate
pipeline_nb.fit(X_train, y_train)
y_pred_nb = pipeline_nb.predict(X_test)

pipeline_rf.fit(X_train, y_train)
y_pred_rf = pipeline_rf.predict(X_test)

# Inspect the genre labels
print("Genre Labels:")
print(mlb.classes_)

# Function to print evaluation metrics
def print_evaluation_metrics(y_test, y_pred, model_name):
    print(f"Evaluation metrics for {model_name}:")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, average='micro'))
    print("Recall:", recall_score(y_test, y_pred, average='micro'))
    print("F1 Score:", f1_score(y_test, y_pred, average='micro'))
    print(classification_report(y_test, y_pred, target_names=mlb.classes_))

# Print evaluation metrics for Multinomial Naive Bayes
print_evaluation_metrics(y_test, y_pred_nb, "Multinomial Naive Bayes")

# Print evaluation metrics for Random Forest
print_evaluation_metrics(y_test, y_pred_rf, "Random Forest")
