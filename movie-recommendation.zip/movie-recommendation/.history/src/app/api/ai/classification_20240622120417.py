import pandas as pd
import ast
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Adjust path as necessary

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])

# Convert genres from string representation of list of dicts to list of genres
def parse_genres(genres_str):
    try:
        genres_list = ast.literal_eval(genres_str)
        return [genre['name'] for genre in genres_list]
    except (ValueError, SyntaxError):
        return []

df['genres'] = df['genres'].apply(parse_genres)

# Text preprocessing
X = df['overview']
y = df['genres']

# Use MultiLabelBinarizer to convert genres to a binary matrix
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(y)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline for Naive Bayes
nb_pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('clf', MultiOutputClassifier(MultinomialNB()))
])

# Train the Naive Bayes model
nb_pipeline.fit(X_train, y_train)

# Predict with Naive Bayes model
y_pred_nb = nb_pipeline.predict(X_test)

# Create a pipeline for Random Forest
rf_pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),
    ('clf', MultiOutputClassifier(RandomForestClassifier(n_estimators=200, max_depth=20, min_samples_split=10, random_state=42)))
])

# Train the Random Forest model
rf_pipeline.fit(X_train, y_train)

# Predict with Random Forest model
y_pred_rf = rf_pipeline.predict(X_test)

# Define function to evaluate model
def evaluate_model(y_test, y_pred, model_name):
    print(f"=== {model_name} ===")
    print("Accuracy: ", accuracy_score(y_test, y_pred))
    print("Precision: ", precision_score(y_test, y_pred, average='weighted', zero_division=0))
    print("Recall: ", recall_score(y_test, y_pred, average='weighted', zero_division=0))
    print("F1-Score: ", f1_score(y_test, y_pred, average='weighted', zero_division=0))
    print(classification_report(y_test, y_pred, target_names=mlb.classes_, zero_division=0))

# Evaluate Naive Bayes Model
evaluate_model(y_test, y_pred_nb, "Naive Bayes")

# Evaluate Random Forest Model
evaluate_model(y_test, y_pred_rf, "Random Forest")
