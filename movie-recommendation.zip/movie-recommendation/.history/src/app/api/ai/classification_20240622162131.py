import pandas as pd
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.metrics import classification_report, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
from joblib import parallel_backend

# Load the cleaned data
data = pd.read_csv('src/app/api/ai/cleaned_movie_set.csv')

# Function to clean the genres column
def clean_genres(genres_str):
    genres_list = ast.literal_eval(genres_str)
    return [genre['name'] for genre in genres_list]

# Apply the function to the genres column
data['genres'] = data['genres'].apply(clean_genres)

# Remove rows with NaN values in the 'overview' column
data = data.dropna(subset=['overview'])

# Prepare the Data
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(data['genres'])

# Split the Data
X_train, X_test, y_train, y_test = train_test_split(data['overview'], y, test_size=0.2, random_state=42)

# Build Pipeline for Random Forest
pipeline_rf = Pipeline([
    ('tfidf', vectorizer),
    ('clf', MultiOutputClassifier(RandomForestClassifier(random_state=42)))
])

# Define parameter grid for Grid Search
param_grid = {
    'clf__estimator__n_estimators': [50, 100, 200],
    'clf__estimator__max_depth': [None, 10, 20],
    'clf__estimator__min_samples_split': [2, 5, 10]
}

# Perform Grid Search with joblib's progress bar
with parallel_backend('joblib'):
    grid_search_rf = GridSearchCV(pipeline_rf, param_grid, cv=3, n_jobs=-1, verbose=1)
    grid_search_rf.fit(X_train, y_train)

# Get the best model from Grid Search
best_rf_model = grid_search_rf.best_estimator_

# Train the best model
best_rf_model.fit(X_train, y_train)
y_pred_rf_best = best_rf_model.predict(X_test)

# Function to print evaluation metrics
def print_evaluation_metrics(y_test, y_pred, mlb):
    print("Evaluation metrics:")
    print("Precision:", precision_score(y_test, y_pred, average='micro'))
    print("Recall:", recall_score(y_test, y_pred, average='micro'))
    print("F1 Score:", f1_score(y_test, y_pred, average='micro'))
    print(classification_report(y_test, y_pred, target_names=mlb.classes_))

# Print evaluation metrics for the best Random Forest model
y_pred_rf_best = best_rf_model.predict(X_test)
print_evaluation_metrics(y_test, y_pred_rf_best, mlb)
