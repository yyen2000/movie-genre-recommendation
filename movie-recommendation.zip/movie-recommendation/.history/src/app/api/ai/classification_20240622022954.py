import pandas as pd
import ast
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.multioutput import MultiOutputClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
import pickle

# Load dataset
df = pd.read_csv('src/app/api/ai/movie_set.csv')  # Ensure the CSV contains 'title', 'overview', and 'genres'

# Handling missing values in 'overview'
df = df.dropna(subset=['overview'])  # Remove rows with missing 'overview'

# Convert the genres from string representation of list of dicts to list of genres
df['genres'] = df['genres'].apply(lambda x: [genre['name'] for genre in ast.literal_eval(x)])

# Text preprocessing
X = df['overview']
y = df['genres']

# Use MultiLabelBinarizer to convert genres to a binary matrix
mlb = MultiLabelBinarizer()
y = mlb.fit_transform(y)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline with TfidfVectorizer and MultinomialNB wrapped in MultiOutputClassifier
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', ngram_range=(1, 2))),  # Use bigrams
    ('clf', MultiOutputClassifier(MultinomialNB())),
])

# Train the model
pipeline.fit(X_train, y_train)

# Evaluate the model
y_pred = pipeline.predict(X_test)

# Print classification report
report = classification_report(y_test, y_pred, target_names=mlb.classes_)
print(report)

# Save the model and the binarizer to a file
with open('movie_genre_classifier.pkl', 'wb') as f:
    pickle.dump((pipeline, mlb), f)
