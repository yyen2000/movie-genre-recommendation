from flask import Flask, request, jsonify
import pickle
import os

app = Flask(__name__)

# Load the trained models
model_path_nb = os.path.join(os.path.dirname(__file__), 'pipeline_nb.pkl')
with open(model_path_nb, 'rb') as f:
    pipeline_nb = pickle.load(f)

model_path_rf = os.path.join(os.path.dirname(__file__), 'pipeline_rf.pkl')
with open(model_path_rf, 'rb') as f:
    pipeline_rf = pickle.load(f)

# Define an endpoint for predicting genres
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    overview = data['overview']
    
    prediction_nb = pipeline_nb.predict([overview])
    prediction_rf = pipeline_rf.predict([overview])

    response = {
        'naive_bayes': prediction_nb.tolist(),
        'random_forest': prediction_rf.tolist()
    }

    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
