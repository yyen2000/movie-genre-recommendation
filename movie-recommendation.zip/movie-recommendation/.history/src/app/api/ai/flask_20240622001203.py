from flask import Flask, request, jsonify
import pickle

app = Flask(__name__)

# Load the pre-trained model
with open('movie_genre_classifier.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    title = data['title']
    overview = data['overview']
    
    # Predict genre
    predicted_genre = model.predict([overview])[0]
    
    return jsonify({'title': title, 'predicted_genre': predicted_genre})

if __name__ == '__main__':
    app.run(debug=True)
