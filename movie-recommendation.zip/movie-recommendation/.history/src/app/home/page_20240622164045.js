'use client'

import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [overview, setOverview] = useState('');
  const [predictedGenres, setPredictedGenres] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/predict', { overview });
      setPredictedGenres(response.data.predicted_genres);
    } catch (error) {
      console.error('Error predicting genres:', error);
    }
  };

  return (
    <div>
      <h1>Movie Genre Prediction</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          value={overview}
          onChange={(e) => setOverview(e.target.value)}
          rows="4"
          cols="50"
          placeholder="Enter movie overview"
        />
        <button type="submit">Predict Genres</button>
      </form>
      {predictedGenres.length > 0 && (
        <div>
          <h2>Predicted Genres:</h2>
          <ul>
            {predictedGenres.map((genre, index) => (
              <li key={index}>{genre}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
