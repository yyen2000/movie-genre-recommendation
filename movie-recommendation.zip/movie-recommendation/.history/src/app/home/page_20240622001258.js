'use client'

import React, { useState } from 'react';

const MovieGenreForm = () => {
    const [title, setTitle] = useState('');
    const [overview, setOverview] = useState('');
    const [predictedGenre, setPredictedGenre] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        const response = await fetch('http://localhost:5000/predict', { 
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title, overview }),
        });

        const data = await response.json();
        setPredictedGenre(data.predicted_genre);
    };

    return (
        <div>
            <h2>Movie Genre Prediction</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Title:
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
                </label>
                <label>
                    Overview:
                    <textarea value={overview} onChange={(e) => setOverview(e.target.value)} required></textarea>
                </label>
                <button type="submit">Predict Genre</button>
            </form>
            {predictedGenre && <p>Predicted Genre: {predictedGenre}</p>}
        </div>
    );
};

export default MovieGenreForm;
