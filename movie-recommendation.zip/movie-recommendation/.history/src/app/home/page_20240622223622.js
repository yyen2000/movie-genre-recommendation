'use client'

import { useState } from 'react';
import axios from 'axios';

const demoOverviews = [
  "A young man is bestowed with incredible martial arts skills and a mystical force known as the Iron Fist.",
  "The seeds of love are planted when Lisa, a high-powered investment banker, receives flowers from a secret admirer. But when his fairy-tale fantasies clash with her workaholic ways, they soon find out that sometimes, it's harder than it seems for love to conquer all.",
  "In the 22nd century, a paraplegic Marine is dispatched to the moon Pandora on a unique mission."
];

export default function Home() {
  const [activeTab, setActiveTab] = useState('New');
  const [overview, setOverview] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post('http://localhost:5000/predict', { overview });
      setResult(response.data);
    } catch (error) {
      console.error('Error making prediction', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='font-serif text-white p-6 w-full'>
      <h1 className='text-center w-full justify-center flex bg-gradient-to-r from-blue-500 via-teal-500 to-pink-500 bg-clip-text text-6xl font-extrabold text-transparent select-none'>
        Movie Genre Identification
      </h1>
      <p className="text-md text-slate-200 text-center">
      Easily identify the genres of any movie with our advanced AI-powered tool. Simply enter a brief description of the movie, and our system will analyze the text to recommend the most fitting genres. Whether you are a movie enthusiast, a researcher, or a content creator, our tool provides accurate genre classifications to help you better understand and categorize movies.
      </p>
      <div className='relative justify-center'>
        <div className="flex justify-center mb-4">
          <button
            className={`px-4 py-2 ${activeTab === 'New' ? 'bg-teal-500 text-white' : 'bg-gray-200 text-gray-700'} rounded-l-lg`}
            onClick={() => setActiveTab('New')}
          >
            New
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'Demo' ? 'bg-teal-500 text-white' : 'bg-gray-200 text-gray-700'} rounded-r-lg`}
            onClick={() => setActiveTab('Demo')}
          >
            Demo
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col items-center w-full">
          {activeTab === 'New' && (
            <div className="flex w-full justify-center items-center space-x-4">
              <textarea
                value={overview}
                onChange={(e) => setOverview(e.target.value)}
                placeholder="Enter movie overview"
                rows="10"
                className='flex-1 p-2.5 text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-gray-500 focus:border-gray-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'
              ></textarea>
              <button type="submit" className="flex-none inline-flex justify-center p-2 text-blue-600 rounded-full cursor-pointer hover:bg-blue-100 dark:text-blue-500 dark:hover:bg-gray-600">
                <svg className="w-5 h-5 rotate-90 rtl:-rotate-90" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 20">
                  <path d="m17.914 18.594-8-18a1 1 0 0 0-1.828 0l-8 18a1 1 0 0 0 1.157 1.376L8 18.281V9a1 1 0 0 1 2 0v9.281l6.758 1.689a1 1 0 0 0 1.156-1.376Z"/>
                </svg>
                <span className="sr-only">Send message</span>
              </button>
            </div>
          )}
          {activeTab === 'Demo' && (
            <div className="flex flex-col items-center w-full">
              <select
                onChange={(e) => setOverview(e.target.value)}
                className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              >
                <option value="">Select a demo overview</option>
                {demoOverviews.map((item, index) => (
                  <option key={index} value={item} className="truncate">{item}</option>
                ))}
              </select>
              {overview && (
                <textarea
                  value={overview}
                  readOnly
                  rows="10"
                  className='block mt-4 p-2.5 w-full text-sm text-gray-900 bg-gray-200 rounded-lg border border-gray-300'
                ></textarea>
              )}
              <button type="submit" className="flex-none inline-flex justify-center p-2 text-blue-600 rounded-full cursor-pointer hover:bg-blue-100 dark:text-blue-500 dark:hover:bg-gray-600">
                <svg className="w-5 h-5 rotate-90 rtl:-rotate-90" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 20">
                  <path d="m17.914 18.594-8-18a1 1 0 0 0-1.828 0l-8 18a1 1 0 0 0 1.157 1.376L8 18.281V9a1 1 0 0 1 2 0v9.281l6.758 1.689a1 1 0 0 0 1.156-1.376Z"/>
                </svg>
                <span className="sr-only">Send message</span>
              </button>
            </div>
          )}
        </form>
      </div>

      {loading && (
        <div className="flex justify-center mt-8">
          <div className="loader"></div>
        </div>
      )}

      {result && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-center">Genres Recommended Results:</h2>
          <div className="flex justify-center mt-4">
            <table className="table-auto border-collapse border border-gray-800 w-1/2 text-gray-900">
              <thead>
                <tr className="bg-gray-200">
                  <th className="border border-gray-800 px-4 py-2">Model</th>
                  <th className="border border-gray-800 px-4 py-2">Genres</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-800 text-slate-100 px-4 py-2">Naive Bayes</td>
                  <td className="border border-gray-800 text-slate-100 px-4 py-2">{result.naive_bayes.join(', ')}</td>
                </tr>
                <tr>
                  <td className="border border-gray-800 text-slate-100 px-4 py-2">Random Forest</td>
                  <td className="border border-gray-800 text-slate-100 px-4 py-2">{result.random_forest.join(', ')}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
