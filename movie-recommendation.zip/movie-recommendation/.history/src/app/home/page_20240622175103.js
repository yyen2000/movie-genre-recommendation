'use client'

import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [overview, setOverview] = useState('');
  const [result, setResult] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/predict', { overview });
      setResult(response.data);
    } catch (error) {
      console.error('Error making prediction', error);
    }
  };

  return (
    <div>
      <h1>Movie Genre Prediction</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          value={overview}
          onChange={(e) => setOverview(e.target.value)}
          placeholder="Enter movie overview"
          rows="10"
          cols="50"
        ></textarea>
        <br />
        <button type="submit">Predict Genres</button>
      </form>

      {result && (
        <div>
          <h2>Prediction Results</h2>
          <div>
            <h3>Naive Bayes:</h3>
            <p>{result.naive_bayes}</p>
          </div>
          <div>
            <h3>Random Forest:</h3>
            <p>{result.random_forest}</p>
          </div>
        </div>
      )}
    </div>
  );
}
