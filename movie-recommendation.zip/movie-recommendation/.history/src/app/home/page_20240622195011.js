'use client'

import { useState } from 'react';
import axios from 'axios';

const demoOverviews = [
  "A young man is bestowed with incredible martial arts skills and a mystical force known as the Iron Fist.",
  "An insomniac office worker and a devil-may-care soap maker form an underground fight club.",
  "In the 22nd century, a paraplegic Marine is dispatched to the moon Pandora on a unique mission."
];

export default function Home() {
  const [activeTab, setActiveTab] = useState('New');
  const [overview, setOverview] = useState('');
  const [result, setResult] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/predict', { overview });
      setResult(response.data);
    } catch (error) {
      console.error('Error making prediction', error);
    }
  };

  return (
    <div className='flex flex-col font-serif min-h-screen bg-gray-900 text-white p-6'>
      <h1 className='text-center w-full py-4 justify-center flex bg-gradient-to-r from-blue-500 via-teal-500 to-pink-500 bg-clip-text text-6xl font-extrabold text-transparent select-none'>
        Movie Genre Identification
      </h1>
      <p className="text-md text-slate-200 mb-8 text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      <div className='relative justify-center'>
        <div className="flex justify-center mb-4">
          <button
            className={`px-4 py-2 ${activeTab === 'New' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'} rounded-l-lg`}
            onClick={() => setActiveTab('New')}
          >
            New
          </button>
          <button
            className={`px-4 py-2 ${activeTab === 'Demo' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'} rounded-r-lg`}
            onClick={() => setActiveTab('Demo')}
          >
            Demo
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col items-center w-full">
          {activeTab === 'New' && (
            <div className="flex w-full justify-center items-center space-x-4">
              <textarea
                value={overview}
                onChange={(e) => setOverview(e.target.value)}
                placeholder="Enter movie overview"
                rows="10"
                className='flex-1 p-2.5 text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'
              ></textarea>
              <button type="submit" className="flex-none inline-flex justify-center p-2 text-blue-600 rounded-full cursor-pointer hover:bg-blue-100 dark:text-blue-500 dark:hover:bg-gray-600">
                <svg className="w-5 h-5 rotate-90 rtl:-rotate-90" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 20">
                  <path d="m17.914 18.594-8-18a1 1 0 0 0-1.828 0l-8 18a1 1 0 0 0 1.157 1.376L8 18.281V9a1 1 0 0 1 2 0v9.281l6.758 1.689a1 1 0 0 0 1.156-1.376Z"/>
                </svg>
                <span className="sr-only">Send message</span>
              </button>
            </div>
          )}
          {activeTab === 'Demo' && (
            <div className="flex flex-col items-center w-full">
              <select
                onChange={(e) => setOverview(e.target.value)}
                className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              >
                <option value="">Select a demo overview</option>
                {demoOverviews.map((item, index) => (
                  <option key={index} value={item}>{item}</option>
                ))}
              </select>
              {overview && (
                <textarea
                  value={overview}
                  readOnly
                  rows="10"
                  className='block mt-4 p-2.5 w-full text-sm text-gray-900 bg-gray-200 rounded-lg border border-gray-300'
                ></textarea>
              )}
            </div>
          )}
        </form>
      </div>

      {result && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-center">Prediction Results</h2>
          <div className="mt-4">
            <h3 className="text-xl font-semibold">Naive Bayes:</h3>
            <p>{result.naive_bayes.join(', ')}</p>
          </div>
          <div className="mt-4">
            <h3 className="text-xl font-semibold">Random Forest:</h3>
            <p>{result.random_forest.join(', ')}</p>
          </div>
        </div>
      )}
    </div>
  );
}
