'use client'

import React, { useState } from 'react';

const MovieRecommendationForm = () => {
    const [title, setTitle] = useState('');
    const [genre, setGenre] = useState('');
    const [voteAverage, setVoteAverage] = useState('');
    const [voteCount, setVoteCount] = useState('');
    const [recommendation, setRecommendation] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title,
                genre,
                vote_average: parseFloat(voteAverage),
                vote_count: parseInt(voteCount),
            }),
        });

        const data = await response.json();
        setRecommendation(data.recommendation);
    };

    return (
        <div>
            <h2>Movie Recommendation</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Title:
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
                </label>
                <label>
                    Genre:
                    <input type="text" value={genre} onChange={(e) => setGenre(e.target.value)} />
                </label>
                <label>
                    Vote Average:
                    <input type="number" value={voteAverage} onChange={(e) => setVoteAverage(e.target.value)} />
                </label>
                <label>
                    Vote Count:
                    <input type="number" value={voteCount} onChange={(e) => setVoteCount(e.target.value)} />
                </label>
                <button type="submit">Get Recommendation</button>
            </form>
            {recommendation && <p>Recommendation: {recommendation}</p>}
        </div>
    );
};

export default MovieRecommendationForm;
